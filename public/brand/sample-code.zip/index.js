console.log('Hello World');

function calculate(a, b) {
  return a + b;
}
